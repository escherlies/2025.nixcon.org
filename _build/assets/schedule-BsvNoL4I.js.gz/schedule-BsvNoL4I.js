import{w as x,i as c,p as f,l as o,b as n,C as m,t as d,P as g}from"./web-SALwWEIV.js";import{S as k}from"./Section-DBlcVHQU.js";import{T as _,S as b}from"./Ui-Cirr_H-3.js";var $=d("<div class=mt-6>"),y=d('<div class="relative min-h-svh text-white"><div><!$><!/><div class><div style=padding-top:100px;><div></div></div></div></div><div class=h-20>');function P(){let i;return x(()=>{if(!customElements.get("pretalx-schedule")){const e=document.createElement("script");e.type="text/javascript",e.src="https://talks.nixcon.org/nixcon-2025/widgets/schedule.js",document.head.appendChild(e)}}),(()=>{var e=c(y),t=e.firstChild,p=t.firstChild,[s,h]=f(p.nextSibling),u=s.nextSibling,r=u.firstChild,v=r.firstChild;t.style.setProperty("background-color","var(--theme-background-translucent)"),o(t,n(k,{class:"!min-h-[10vh] !pt-20 !pb-10 px-5",get children(){return[n(_,{children:"Schedule"}),(()=>{var a=c($);return o(a,n(b,{href:"https://talks.nixcon.org/nixcon-2025/schedule/",target:"_blank",rel:"noopener noreferrer",children:"Open in Pretalx"})),a})()]}}),s,h);var l=i;return typeof l=="function"?g(l,r):i=r,m(v,"innerHTML",`
                  <pretalx-schedule
                    event-url="https://talks.nixcon.org/nixcon-2025/"
                    locale="en"
                    format="grid"
                    style="--pretalx-clr-primary: #ff8b00; --pretalx-sticky-top-offset: 72px; background-color: #fafafa; width: 100vw; display: block;">
                  </pretalx-schedule>
                  <noscript>
                    <div class="pretalx-widget">
                      <div class="pretalx-widget-info-message">
                        JavaScript is disabled in your browser. To access our schedule without JavaScript,
                        please <a target="_blank" href="https://talks.nixcon.org/nixcon-2025/schedule/">click here</a>.
                      </div>
                    </div>
                  </noscript>
                `),e})()}export{P as default};
